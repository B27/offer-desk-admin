<script>
	import Nav from '../components/Nav.svelte';
	import {user} from '../stores/user.js';
	import { onMount } from 'svelte';
	import * as sapper from '@sapper/app'

	export let segment;

    let oldSession; 
    onMount(async () =>{
        if(segment === 'login')return;
        oldSession = user.refresh();
        if(!await oldSession)return sapper.goto('/login');
    });
</script>

<style>
	main {
		position: relative;
		max-width: 56em;
		background-color: white;
		padding: 2em;
		margin: 0 auto;
		box-sizing: border-box;
	}
</style>

{#if segment !== 'login'}
<Nav {segment}/>
{/if}
<!-- <main> -->
	<slot></slot>
<!-- </main> -->